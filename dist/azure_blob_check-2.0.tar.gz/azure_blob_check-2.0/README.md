# azure_blob_check

azure 스토리지 계정 내 컨테이너에 저장된 blob 목록을 확인하기 위해 사용함

## Installation

```python
pip install pyquibase
```

## Usage

Python blob_check [blob_name] [container_name] [output_excel_name]
