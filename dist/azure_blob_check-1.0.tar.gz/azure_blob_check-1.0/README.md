# azure_blob_check
<<<<<<< HEAD
=======

azure 스토리지 계정 내 컨테이너에 저장된 blob 목록을 확인하기 위해 사용함

## Installation

```python
pip install azure_blob_check
```

## Usage

python blob_check.py [blob_name] [container_name] [output_excel_name]
>>>>>>> 5cbe2d41f58a9effc81aba9ad6fa51b2bc1a26a1
